/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apt_management_package;

import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;



/**
 *
 * @author RAJATH
 */
public class main_page extends javax.swing.JFrame {
    Connection con=null;
    PreparedStatement st=null;
    int flat_rent_id;
    int flat_id1=1;
    ResultSet r=null;
    int apt_id1=0;
    boolean e=false;
    int main_id=0;
    int total_rent=0;
    int cust_phone_num_check=0;
    
    
    /**
     * Creates new form main_page
     */
    public main_page() {
        initComponents();
        connect();
        auto_apt_id();
        jTextField2.setEditable(false);
        apt_id_tf.setEditable(false);
        Scroll2.setOpaque(false);
        apt_table_panel.setOpaque(false);
        cust_table_panel.setOpaque(false);
        cust_table_panel1.setOpaque(false);
        customer_Scroll1.setOpaque(false);
        customer_Scroll2.setOpaque(false);
        flat_Scroll1.setOpaque(false);
        flat_table_panel1.setOpaque(false);
        jPanel5.setOpaque(false);
        apt_table_panel.setOpaque(false);
        apt_Scroll.setOpaque(false);
        jPanel6.setOpaque(false);
        flat_Scroll1.setOpaque(false);
        flat_table_panel1.setOpaque(false);
        jPanel7.setOpaque(false);
                cust_table_panel.setOpaque(false);
                customer_Scroll1.setOpaque(false);
                cust_details_table.setOpaque(false);
                flat_details_table1.setOpaque(false);
                jPanel8.setOpaque(false);
                s_v_pane.setOpaque(false);
                Scroll2.setOpaque(false);
                cust_table_panel1.setOpaque(false);
                customer_Scroll2.setOpaque(false);
                jPanel11.setOpaque(false);
                jScrollPane1.setOpaque(false);
        //jPanel10.setOpaque(false);
        jPanel11.setOpaque(false);
        //jPanel2.setOpaque(false);
       // jPanel3.setOpaque(false);
        //jPanel4.setOpaque(false);
        jPanel5.setOpaque(false);
        jPanel6.setOpaque(false);
        jPanel7.setOpaque(false);
        jPanel8.setOpaque(false);
        //jPanel9.setOpaque(false);
        jScrollPane1.setOpaque(false);
        
        this.setSize( Toolkit.getDefaultToolkit().getScreenSize() );
        apt_table_panel.setVisible(false);
        apt_Scroll.setVisible(true);
        apt_details_table.setVisible(true);
        
        apt_id_get();
        flat_table_panel1.setVisible(false);
        bhk_get();
        cust_id_set.setEditable(false);
        cust_table_panel.setVisible(false);
        s_v_pane.setVisible(false);
        cust_table_panel1.setVisible(false);
        rent_total.setEditable(false);
        s_id.setEditable(false);
        i_flat_id.setEditable(false);
         
          jPanel11.setVisible(false);
        
        add();
        da();
        /*pay_view p=new pay_view();
             p.setVisible(true);*/
        //Trigger();
    }
    public void da() {
        int m=0;
        DateFormat dateFormat = new SimpleDateFormat("MM");
        Calendar cal = Calendar.getInstance();
        String d=dateFormat.format(cal.getTime());
        switch(d){
            case "01":m=0;
                    break;
                    case "02":m=1;
                    break;
                    case "03":m=2;
                    break;
                    case "04":m=3;
                    break;
                    case "05":m=4;
                    break;
                    case "06":m=5;
                    break;
                    case "07":m=6;
                    break;
                    case "08":m=7;
                    break;
                    case "09":m=8;
                    break;
                    case "10":m=9;
                    break;
                    case "11":m=10;
                    break;
                    case "12":m=11;
                    break;
                    
                    
        }
        
        DateFormat dateFormat1 = new SimpleDateFormat("dd-MM-yyyy");
        Calendar cal1 = Calendar.getInstance();
        String d1=dateFormat1.format(cal.getTime());
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, 10);
        calendar.set(Calendar.MONTH, m);
        
        String alarmtime=dateFormat1.format(calendar.getTime()); 
         if(d1.equals(alarmtime)){
             pay_view p=new pay_view();
             p.setVisible(true);
             
         }

        /*_timer = new Timer();
        _timer.schedule(new AlarmTask(), alarmTime);*/
    }
    public void add(){
        Statement s;
        ResultSet r;
        try{
            String query="select * from customer;";
            s=con.createStatement();
            r=s.executeQuery(query);
            
           
            int i=0;
            int count = 0;

            while (r.next()) {
                ++count;
                // Get data from the current row and use it
                }
            String[] c_id=new String[count];
            String[] paytype=new String[5];
            paytype[0]="Debit Card";
            paytype[1]="Credit Card";
            paytype[2]="Phone Pay";
            paytype[3]="Google Pay";
            paytype[4]="Paytm";
            DefaultComboBoxModel mod1=new DefaultComboBoxModel(paytype);
            jComboBox2.setModel(mod1);
            r.beforeFirst();
            boolean record=r.next();
            if(!record){
                JOptionPane.showMessageDialog(null, "no records");
            }else{
                do{
                    c_id[i]=String.valueOf(r.getInt("cust_id"));
                    
                    i++;
                    }while(r.next());
            }
            DefaultComboBoxModel mod=new DefaultComboBoxModel(c_id);
            jComboBox1.setModel(mod);
           
            
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    public void bhk_get(){
        Statement s;
        ResultSet r;
        try{
            String query="select * from rent;";
            s=con.createStatement();
            r=s.executeQuery(query);
            
           
            int i=0;
            int count = 0;

            while (r.next()) {
                ++count;
                // Get data from the current row and use it
                }
            String[] bhk_s=new String[count];
            //String[] apt_name_s=new String[count];
            r.beforeFirst();
            boolean record=r.next();
            if(!record){
                JOptionPane.showMessageDialog(null, "no records");
            }else{
                do{
                    bhk_s[i]=String.valueOf(r.getInt("bhk"));
                    //apt_name_s[i]=r.getString("apt_name");
                    i++;
                    }while(r.next());
            }
            DefaultComboBoxModel mod_bhk=new DefaultComboBoxModel(bhk_s);
            //DefaultComboBoxModel mod1=new DefaultComboBoxModel(apt_name_s);
           i_bhk.setModel(mod_bhk);
            //d_apt_name_tf.setModel(mod1);
            
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    
    public void connect()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con=DriverManager.getConnection("jdbc:mysql://localhost/apt_db","root","root123");
            
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        apt_id_tf = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        apt_name_tf = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        apt_address_tf = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        apt_city_tf = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        apt_state_tf = new javax.swing.JTextField();
        add_apt_details_button = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        apt_no_flats_tf = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        apt_table_panel = new javax.swing.JPanel();
        apt_Scroll = new javax.swing.JScrollPane();
        apt_details_table = new javax.swing.JTable();
        apt_update_win_button = new javax.swing.JButton();
        apt_delete_win_button = new javax.swing.JButton();
        apt_view_button = new javax.swing.JButton();
        jLabel33 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        i_flat_id = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        i_floor_no = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        i_add_flat_button = new javax.swing.JButton();
        i_flat_apt_id = new javax.swing.JComboBox<>();
        i_bhk = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        update_flat = new javax.swing.JButton();
        delete_flat = new javax.swing.JButton();
        view_flat_button = new javax.swing.JButton();
        flat_table_panel1 = new javax.swing.JPanel();
        flat_Scroll1 = new javax.swing.JScrollPane();
        flat_details_table1 = new javax.swing.JTable();
        jLabel35 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        i_flat_apt_id1 = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        i_flat_id1 = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        cust_id_set = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        cust_name_set = new javax.swing.JTextField();
        cust_phone = new javax.swing.JTextField();
        cust_email = new javax.swing.JTextField();
        cust_rent = new javax.swing.JTextField();
        cust_main = new javax.swing.JTextField();
        cust_date = new com.toedter.calendar.JDateChooser();
        add_cust = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        cust_table_panel = new javax.swing.JPanel();
        customer_Scroll1 = new javax.swing.JScrollPane();
        cust_details_table = new javax.swing.JTable();
        jLabel40 = new javax.swing.JLabel();
        d_cust = new javax.swing.JButton();
        u_customer = new javax.swing.JButton();
        v_cust = new javax.swing.JButton();
        jLabel36 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        s_name = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        s_apt_id = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        s_shift = new javax.swing.JComboBox<>();
        add_security_button = new javax.swing.JButton();
        s_id = new javax.swing.JTextField();
        s_v_pane = new javax.swing.JPanel();
        Scroll2 = new javax.swing.JScrollPane();
        s_v_table = new javax.swing.JTable();
        s_view = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel37 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel28 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel29 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel30 = new javax.swing.JLabel();
        rent_total = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        not_paid_b = new javax.swing.JButton();
        paid_b = new javax.swing.JButton();
        cust_table_panel1 = new javax.swing.JPanel();
        customer_Scroll2 = new javax.swing.JScrollPane();
        cust_details_table1 = new javax.swing.JTable();
        update_rent_button = new javax.swing.JButton();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();
        jLabel34 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel32 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jPanel11 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel39 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTabbedPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane1MouseClicked(evt);
            }
        });

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        apt_id_tf.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Aparrtment ID");

        jLabel2.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Apartment Name");

        apt_name_tf.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        apt_name_tf.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                apt_name_tfMouseClicked(evt);
            }
        });
        apt_name_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apt_name_tfActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Address");

        apt_address_tf.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("City");

        apt_city_tf.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("State");

        apt_state_tf.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        apt_state_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apt_state_tfActionPerformed(evt);
            }
        });

        add_apt_details_button.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        add_apt_details_button.setText("Add Apartment");
        add_apt_details_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_apt_details_buttonActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("No Of Flats");

        apt_no_flats_tf.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        apt_no_flats_tf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                apt_no_flats_tfKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(95, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(add_apt_details_button, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(85, 85, 85)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(apt_address_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(apt_state_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(apt_city_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(apt_no_flats_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(apt_id_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(apt_name_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(59, 59, 59))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(apt_name_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(apt_id_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(apt_no_flats_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(apt_address_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(apt_city_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(apt_state_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addComponent(add_apt_details_button)
                .addGap(41, 41, 41))
        );

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(103, 111, -1, -1));

        jLabel7.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Apartment Details");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(759, 38, -1, 66));

        apt_Scroll.setBorder(null);
        apt_Scroll.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N

        apt_details_table.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        apt_details_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        apt_details_table.setRowHeight(25);
        apt_Scroll.setViewportView(apt_details_table);

        javax.swing.GroupLayout apt_table_panelLayout = new javax.swing.GroupLayout(apt_table_panel);
        apt_table_panel.setLayout(apt_table_panelLayout);
        apt_table_panelLayout.setHorizontalGroup(
            apt_table_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(apt_Scroll, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1007, Short.MAX_VALUE)
        );
        apt_table_panelLayout.setVerticalGroup(
            apt_table_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, apt_table_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(apt_Scroll, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel1.add(apt_table_panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(759, 111, -1, 401));

        apt_update_win_button.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        apt_update_win_button.setText("Update Apartment");
        apt_update_win_button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        apt_update_win_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apt_update_win_buttonActionPerformed(evt);
            }
        });
        jPanel1.add(apt_update_win_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(451, 578, 150, 30));

        apt_delete_win_button.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        apt_delete_win_button.setText("Delete Apartment");
        apt_delete_win_button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        apt_delete_win_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apt_delete_win_buttonActionPerformed(evt);
            }
        });
        jPanel1.add(apt_delete_win_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(687, 578, 150, 30));

        apt_view_button.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        apt_view_button.setText("View Apartments");
        apt_view_button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        apt_view_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apt_view_buttonActionPerformed(evt);
            }
        });
        jPanel1.add(apt_view_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(923, 578, 150, 30));

        jLabel33.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/aptpics.jpg"))); // NOI18N
        jLabel33.setText("jLabel33");
        jPanel1.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1900, 1800));

        jTabbedPane1.addTab("Apartment Details", jPanel1);

        jPanel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel2MouseClicked(evt);
            }
        });
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel8.setText("Flat ID");
        jLabel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        i_flat_id.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        i_flat_id.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                i_flat_idKeyTyped(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel9.setText("Apartment ID");
        jLabel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel10.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel10.setText("Floor");
        jLabel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        i_floor_no.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        i_floor_no.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                i_floor_noKeyTyped(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel11.setText("BHK");
        jLabel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        i_add_flat_button.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        i_add_flat_button.setText("Add Flat");
        i_add_flat_button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        i_add_flat_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_add_flat_buttonActionPerformed(evt);
            }
        });

        i_flat_apt_id.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        i_flat_apt_id.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
                i_flat_apt_idPopupMenuCanceled(evt);
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                i_flat_apt_idPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                i_flat_apt_idPopupMenuWillBecomeVisible(evt);
            }
        });
        i_flat_apt_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_flat_apt_idActionPerformed(evt);
            }
        });

        i_bhk.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(85, 85, 85)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(i_floor_no, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(i_bhk, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(85, 85, 85)
                                .addComponent(i_flat_apt_id, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(85, 85, 85)
                                .addComponent(i_flat_id))))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(224, 224, 224)
                        .addComponent(i_add_flat_button, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(105, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(55, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_flat_apt_id, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_flat_id, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_floor_no, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_bhk, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(54, 54, 54)
                .addComponent(i_add_flat_button, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64))
        );

        jPanel2.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 131, -1, -1));

        jLabel12.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 36)); // NOI18N
        jLabel12.setText("Flat Details");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(632, 46, 306, 78));

        update_flat.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        update_flat.setText("Update Flat");
        update_flat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        update_flat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_flatActionPerformed(evt);
            }
        });
        jPanel2.add(update_flat, new org.netbeans.lib.awtextra.AbsoluteConstraints(406, 594, 150, 30));

        delete_flat.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        delete_flat.setText("Delete Flat");
        delete_flat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        delete_flat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_flatActionPerformed(evt);
            }
        });
        jPanel2.add(delete_flat, new org.netbeans.lib.awtextra.AbsoluteConstraints(642, 594, 150, 30));

        view_flat_button.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        view_flat_button.setText("View Flat");
        view_flat_button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        view_flat_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                view_flat_buttonActionPerformed(evt);
            }
        });
        jPanel2.add(view_flat_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(878, 594, 150, 30));

        flat_Scroll1.setBorder(null);
        flat_Scroll1.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N

        flat_details_table1.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        flat_details_table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        flat_details_table1.setRowHeight(25);
        flat_Scroll1.setViewportView(flat_details_table1);

        javax.swing.GroupLayout flat_table_panel1Layout = new javax.swing.GroupLayout(flat_table_panel1);
        flat_table_panel1.setLayout(flat_table_panel1Layout);
        flat_table_panel1Layout.setHorizontalGroup(
            flat_table_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(flat_Scroll1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1007, Short.MAX_VALUE)
        );
        flat_table_panel1Layout.setVerticalGroup(
            flat_table_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, flat_table_panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(flat_Scroll1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel2.add(flat_table_panel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(725, 131, -1, 383));

        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/apt1.jpg"))); // NOI18N
        jPanel2.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1920, 1800));

        jTabbedPane1.addTab("Flat Details", jPanel2);

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        i_flat_apt_id1.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        i_flat_apt_id1.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                i_flat_apt_id1PopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        i_flat_apt_id1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_flat_apt_id1ActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel13.setText("Apartment ID");
        jLabel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel14.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel14.setText("Flat ID");
        jLabel14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        i_flat_id1.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        i_flat_id1.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
                i_flat_id1PopupMenuCanceled(evt);
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                i_flat_id1PopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        i_flat_id1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_flat_id1ActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel15.setText("Customer ID");
        jLabel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        cust_id_set.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        jLabel20.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel20.setText("Customer Name");
        jLabel20.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel21.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel21.setText("Phone No.");
        jLabel21.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel22.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel22.setText("Email ID");
        jLabel22.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel23.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel23.setText("Date Of Occupying ");
        jLabel23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel24.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel24.setText("Rent Amount");
        jLabel24.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel25.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel25.setText("Maintenance Amount");
        jLabel25.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        cust_name_set.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        cust_phone.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        cust_phone.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cust_phoneKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cust_phoneKeyTyped(evt);
            }
        });

        cust_email.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        cust_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cust_emailActionPerformed(evt);
            }
        });
        cust_email.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cust_emailKeyTyped(evt);
            }
        });

        cust_rent.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        cust_main.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        add_cust.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        add_cust.setText("Add Customer");
        add_cust.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        add_cust.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_custActionPerformed(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel26.setText("Total Amount");
        jLabel26.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTextField1.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(122, 122, 122)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(62, 62, 62)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(i_flat_apt_id1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(i_flat_id1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cust_id_set)
                    .addComponent(cust_name_set)
                    .addComponent(cust_phone)
                    .addComponent(cust_email)
                    .addComponent(cust_date, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                    .addComponent(cust_rent)
                    .addComponent(cust_main)
                    .addComponent(jTextField1))
                .addGap(142, 142, 142))
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(265, 265, 265)
                .addComponent(add_cust, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(i_flat_apt_id1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(i_flat_id1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)))
                .addGap(20, 20, 20)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cust_id_set, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cust_name_set, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cust_phone, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cust_email, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cust_date, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cust_rent, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cust_main, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                .addComponent(add_cust, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );

        jPanel3.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 130, -1, -1));

        customer_Scroll1.setBorder(null);
        customer_Scroll1.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N

        cust_details_table.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        cust_details_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        cust_details_table.setRowHeight(25);
        customer_Scroll1.setViewportView(cust_details_table);

        javax.swing.GroupLayout cust_table_panelLayout = new javax.swing.GroupLayout(cust_table_panel);
        cust_table_panel.setLayout(cust_table_panelLayout);
        cust_table_panelLayout.setHorizontalGroup(
            cust_table_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(customer_Scroll1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1053, Short.MAX_VALUE)
        );
        cust_table_panelLayout.setVerticalGroup(
            cust_table_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cust_table_panelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(customer_Scroll1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel3.add(cust_table_panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(759, 153, -1, 491));

        jLabel40.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 24)); // NOI18N
        jLabel40.setText("Customer Details");
        jPanel3.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(408, 26, 350, 90));

        d_cust.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        d_cust.setText("Delete Customer");
        d_cust.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                d_custActionPerformed(evt);
            }
        });
        jPanel3.add(d_cust, new org.netbeans.lib.awtextra.AbsoluteConstraints(367, 769, 180, 30));

        u_customer.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        u_customer.setText("Update Customer");
        u_customer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                u_customerActionPerformed(evt);
            }
        });
        jPanel3.add(u_customer, new org.netbeans.lib.awtextra.AbsoluteConstraints(647, 769, 180, 30));

        v_cust.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        v_cust.setText("View Customer");
        v_cust.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                v_custActionPerformed(evt);
            }
        });
        jPanel3.add(v_cust, new org.netbeans.lib.awtextra.AbsoluteConstraints(927, 769, 180, 30));

        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/apt3.jpg"))); // NOI18N
        jPanel3.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1920, 1800));

        jTabbedPane1.addTab("Customer Details", jPanel3);

        jPanel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel4MouseClicked(evt);
            }
        });
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel41.setFont(new java.awt.Font("Adobe Caslon Pro", 1, 24)); // NOI18N
        jLabel41.setText("Security Details");
        jPanel4.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 30, 230, 60));

        s_name.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        s_name.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                s_nameMouseClicked(evt);
            }
        });
        s_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                s_nameActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel16.setText("Security Name");
        jLabel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel17.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel17.setText("Shift");
        jLabel17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel18.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel18.setText("Apartment ID");
        jLabel18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        s_apt_id.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        jLabel19.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel19.setText("Security ID");
        jLabel19.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        s_shift.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        add_security_button.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        add_security_button.setText("Add Security");
        add_security_button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        add_security_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_security_buttonActionPerformed(evt);
            }
        });

        s_id.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel8Layout.createSequentialGroup()
                                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel17, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel18, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(44, 44, 44))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel8Layout.createSequentialGroup()
                                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(44, 44, 44)))
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(s_apt_id, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(s_shift, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(s_name, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(s_id, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(add_security_button, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(s_name, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(s_id, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(s_shift, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(s_apt_id, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addComponent(add_security_button, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel4.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(113, 131, -1, -1));

        Scroll2.setBorder(null);
        Scroll2.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N

        s_v_table.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        s_v_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        s_v_table.setRowHeight(25);
        Scroll2.setViewportView(s_v_table);

        javax.swing.GroupLayout s_v_paneLayout = new javax.swing.GroupLayout(s_v_pane);
        s_v_pane.setLayout(s_v_paneLayout);
        s_v_paneLayout.setHorizontalGroup(
            s_v_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Scroll2, javax.swing.GroupLayout.DEFAULT_SIZE, 1211, Short.MAX_VALUE)
        );
        s_v_paneLayout.setVerticalGroup(
            s_v_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, s_v_paneLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Scroll2, javax.swing.GroupLayout.DEFAULT_SIZE, 463, Short.MAX_VALUE))
        );

        jPanel4.add(s_v_pane, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 91, -1, -1));

        s_view.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        s_view.setText("View Security");
        s_view.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        s_view.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                s_viewActionPerformed(evt);
            }
        });
        jPanel4.add(s_view, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 520, 150, 30));

        jButton1.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jButton1.setText("Delete Security");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 450, 150, 30));

        jLabel37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/apt5.jpg"))); // NOI18N
        jPanel4.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1920, 1800));

        jTabbedPane1.addTab("Security Details", jPanel4);

        jPanel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel9MouseClicked(evt);
            }
        });
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel42.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 24)); // NOI18N
        jLabel42.setText("Rent Details");
        jPanel9.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 36, 230, 50));

        jLabel27.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("Customer ID");
        jLabel27.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel9.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 155, 180, 30));

        jComboBox1.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jComboBox1.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                jComboBox1PopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        jPanel9.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(453, 155, 150, 30));

        jLabel28.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("Payment Type");
        jLabel28.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel9.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 212, 180, 30));

        jComboBox2.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jComboBox2.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                jComboBox2PopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        jPanel9.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(453, 212, 150, 30));

        jLabel29.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText("Payment Date");
        jLabel29.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel9.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 268, 180, 30));
        jPanel9.add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(453, 268, 150, 30));

        jLabel30.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("Amount");
        jLabel30.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel9.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 371, 180, 30));

        rent_total.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jPanel9.add(rent_total, new org.netbeans.lib.awtextra.AbsoluteConstraints(453, 371, 150, 30));

        jButton2.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jButton2.setText("Pay");
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 441, 150, 30));

        not_paid_b.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        not_paid_b.setText("View Not Paid Customer");
        not_paid_b.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        not_paid_b.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                not_paid_bActionPerformed(evt);
            }
        });
        jPanel9.add(not_paid_b, new org.netbeans.lib.awtextra.AbsoluteConstraints(428, 441, 250, 30));

        paid_b.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        paid_b.setText("View Paid Customer");
        paid_b.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        paid_b.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paid_bActionPerformed(evt);
            }
        });
        jPanel9.add(paid_b, new org.netbeans.lib.awtextra.AbsoluteConstraints(292, 511, 250, 30));

        customer_Scroll2.setBorder(null);
        customer_Scroll2.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N

        cust_details_table1.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        cust_details_table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        cust_details_table1.setRowHeight(25);
        customer_Scroll2.setViewportView(cust_details_table1);

        javax.swing.GroupLayout cust_table_panel1Layout = new javax.swing.GroupLayout(cust_table_panel1);
        cust_table_panel1.setLayout(cust_table_panel1Layout);
        cust_table_panel1Layout.setHorizontalGroup(
            cust_table_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(customer_Scroll2, javax.swing.GroupLayout.DEFAULT_SIZE, 1211, Short.MAX_VALUE)
        );
        cust_table_panel1Layout.setVerticalGroup(
            cust_table_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cust_table_panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(customer_Scroll2, javax.swing.GroupLayout.DEFAULT_SIZE, 463, Short.MAX_VALUE))
        );

        jPanel9.add(cust_table_panel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(685, 73, -1, -1));

        update_rent_button.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        update_rent_button.setText("Update Rent And Maintenance");
        update_rent_button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        update_rent_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_rent_buttonActionPerformed(evt);
            }
        });
        jPanel9.add(update_rent_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(292, 587, 250, 30));
        jPanel9.add(jDateChooser2, new org.netbeans.lib.awtextra.AbsoluteConstraints(453, 323, 150, 30));

        jLabel34.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("Paying for month/year");
        jLabel34.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel9.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 323, 180, 30));

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/apt10_2.jpg"))); // NOI18N
        jPanel9.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1920, 1800));

        jTabbedPane1.addTab("Rent Details", jPanel9);

        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel31.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("Apartment ID");
        jLabel31.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel10.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(166, 130, 180, 30));

        jComboBox3.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jComboBox3.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                jComboBox3PopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        jPanel10.add(jComboBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(397, 130, 150, 30));

        jLabel32.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("No Of Flats Available");
        jLabel32.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel10.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(166, 187, 180, 30));

        jTextField2.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jPanel10.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(397, 187, 150, 30));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)
        );

        jPanel10.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(276, 277, -1, -1));

        jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/flat1.jpg"))); // NOI18N
        jPanel10.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1920, 1810));

        jTabbedPane1.addTab("Summary", jPanel10);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1907, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void apt_state_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apt_state_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apt_state_tfActionPerformed

    private void add_apt_details_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_apt_details_buttonActionPerformed
        // TODO add your handling code here:
        //int apt_id1=Integer.parseInt(apt_id_tf.getText());
        int apt_noofflats=0;
        String check="";
        apt_noofflats=Integer.parseInt(apt_no_flats_tf.getText());
        String apt_name=apt_name_tf.getText();
        String address=apt_address_tf.getText();
        String city=apt_city_tf.getText();
        String state_name=apt_state_tf.getText();
        

        try{
            if(apt_name.equals(check)){
                JOptionPane.showMessageDialog(null,"Enter Apartment name");
                }
            else if(apt_noofflats==0){
                    JOptionPane.showMessageDialog(null,"no of flats cannot be zero");
                }else if(address.equals(check)){
                    JOptionPane.showMessageDialog(null,"Enter Address");
                }
                else if(city.equals(check)){
                    JOptionPane.showMessageDialog(null,"Enter City");
                }
                else if(state_name.equals(check)){
                    JOptionPane.showMessageDialog(null,"Enter State");
                }
             
                         
            else{
            
           
            String ins_apt_id_query="insert into apartments values(?,?,?,?,?,?);";
            st=con.prepareStatement(ins_apt_id_query);
            st.setInt(1,apt_id1);
            st.setString(2,apt_name);
            st.setString(3,address);
            st.setString(4,city);
            st.setString(5,state_name);
            st.setInt(6,apt_noofflats);
            e=st.execute();
            if(!e){  
            JOptionPane.showMessageDialog(null,"Successfully Inserted!!");
            }else{
                JOptionPane.showMessageDialog(null,"wrong");
            }
            apt_table_process();
            
            apt_no_flats_tf.setText("");
            apt_id_tf.setText("");
            apt_name_tf.setText("");
            apt_address_tf.setText("");
            apt_city_tf.setText("");
            apt_state_tf.setText("");
                    apt_id_get();
            }
            
          auto_apt_id();
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
    }//GEN-LAST:event_add_apt_details_buttonActionPerformed

    public void apt_table_process(){
        apt_table_panel.setVisible(true);
        Statement s=null;
        ResultSet rs;
        String apt_select="select * from apartments";
        try {
            s=con.createStatement();
            rs=s.executeQuery(apt_select);
            apt_details_table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException e) {
            // TODO Auto-generated catch block
             JOptionPane.showMessageDialog(null, e);
        }     
        
          
    }
    public void flat_table_process(){
        flat_table_panel1.setVisible(true);
        Statement s=null;
        ResultSet rs;
        String apt_select="select flat_id,apt_id,floor,bhk,active from flat";
        try {
            s=con.createStatement();
            rs=s.executeQuery(apt_select);
            flat_details_table1.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException e) {
            // TODO Auto-generated catch block
             JOptionPane.showMessageDialog(null, e);
        }     
        
          
    }
    private void apt_name_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apt_name_tfActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_apt_name_tfActionPerformed

    public void apt_id_get(){
        Statement s;
        ResultSet r;
        try{
            String query="select * from apartments;";
            s=con.createStatement();
            r=s.executeQuery(query);
            
           
            int i=0;
            int count = 0;

            while (r.next()) {
                ++count;
                // Get data from the current row and use it
                }
            String[] apt_id_s=new String[count];
            //String[] apt_name_s=new String[count];
            r.beforeFirst();
            boolean record=r.next();
            if(!record){
                JOptionPane.showMessageDialog(null, "no records");
            }else{
                do{
                    apt_id_s[i]=String.valueOf(r.getInt("apt_id"));
                    //apt_name_s[i]=r.getString("apt_name");
                    i++;
                    }while(r.next());
            }
            DefaultComboBoxModel mod=new DefaultComboBoxModel(apt_id_s);
            //DefaultComboBoxModel mod1=new DefaultComboBoxModel(apt_name_s);
           i_flat_apt_id.setModel(mod);
           i_flat_apt_id1.setModel(mod);
           s_apt_id.setModel(mod);
           jComboBox3.setModel(mod);
           String[] shift=new String[2];
           shift[0]="Day";
           shift[1]="Night";
           DefaultComboBoxModel mod12=new DefaultComboBoxModel(shift);
           s_shift.setModel(mod12);
            //d_apt_name_tf.setModel(mod1);
            
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    private void apt_name_tfMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_apt_name_tfMouseClicked
        // TODO add your handling code here:
        auto_apt_id();
        /*try{
            int apt_id;
            Statement s;
            String get_apt_id_query="select apt_id from apartments;";
            s=con.createStatement();
            r=s.executeQuery(get_apt_id_query);
            boolean b=r.next();
            if(!b){
                JOptionPane.showMessageDialog(null,"no resultset");
            }
            else{
                r.first();
                apt_id=r.getInt("apt_id");
                for(int i=0;i<r.getRow();i++){

                    if(r.next()){
                    int apt_id_i=r.getInt("apt_id");
                    if(apt_id<apt_id_i){
                        apt_id=apt_id_i;
                    }
                    }
                }
                apt_id1=apt_id+1; 

            }
            apt_id_tf.setText(String.valueOf(apt_id1));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }*/
    }//GEN-LAST:event_apt_name_tfMouseClicked
    public void auto_apt_id(){
        try{
            int apt_id;
            Statement s;
            String get_apt_id_query="select apt_id from apartments;";
            s=con.createStatement();
            r=s.executeQuery(get_apt_id_query);
            boolean b=r.next();
            if(!b){
                JOptionPane.showMessageDialog(null,"no resultset");
            }
            else{
                r.first();
                apt_id=r.getInt("apt_id");
                for(int i=0;i<r.getRow();i++){

                    if(r.next()){
                    int apt_id_i=r.getInt("apt_id");
                    if(apt_id<apt_id_i){
                        apt_id=apt_id_i;
                    }
                    }
                }
                apt_id1=apt_id+1; 

            }
            apt_id_tf.setText(String.valueOf(apt_id1));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
    }
    private void jTabbedPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MouseClicked
        // TODO add your handling code here:
      
    }//GEN-LAST:event_jTabbedPane1MouseClicked

    private void apt_no_flats_tfKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_apt_no_flats_tfKeyTyped
        // TODO add your handling code here:
        char vchar=evt.getKeyChar();
        if(!(Character.isDigit(vchar))
            ||(vchar==KeyEvent.VK_BACK_SPACE)
            ||(vchar==KeyEvent.VK_DELETE)){
        evt.consume();
    }
    }//GEN-LAST:event_apt_no_flats_tfKeyTyped

    private void apt_view_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apt_view_buttonActionPerformed
        // TODO add your handling code here:
        apt_table_process();
    }//GEN-LAST:event_apt_view_buttonActionPerformed

    private void apt_delete_win_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apt_delete_win_buttonActionPerformed
        // TODO add your handling code here:
       AddApartment a=new AddApartment();
       a.setVisible(true);
       
    }//GEN-LAST:event_apt_delete_win_buttonActionPerformed

    private void apt_update_win_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apt_update_win_buttonActionPerformed
        // TODO add your handling code here:
        UpdateApartment u=new UpdateApartment();
        u.setVisible(true);
    }//GEN-LAST:event_apt_update_win_buttonActionPerformed
    public void get_rent_id(){
        int bhk=Integer.parseInt(i_bhk.getSelectedItem().toString());
        PreparedStatement s=null;
        ResultSet rs;
        String apt_select="select rent_id from rent where bhk=?";
        try {
            s=con.prepareStatement(apt_select);
            s.setInt(1, bhk);
            rs=s.executeQuery();
            boolean b=rs.next();
            if(!b){
                JOptionPane.showMessageDialog(null,"no resultset");
            }
            else{
                flat_rent_id=rs.getInt("rent_id");

            }
            
        } catch (SQLException e) {
            // TODO Auto-generated catch block
             JOptionPane.showMessageDialog(null, e);
        }     
        
    }
    private void i_add_flat_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_add_flat_buttonActionPerformed
        // TODO add your handling code here:
        get_rent_id();
        int flat_id=Integer.parseInt(i_flat_id.getText());
        int apt_id=Integer.parseInt(i_flat_apt_id.getSelectedItem().toString());
        int floor=Integer.parseInt(i_floor_no.getText());
        int bhk=Integer.parseInt(i_bhk.getSelectedItem().toString());
        String active="no";
        if(flat_id==0){
            JOptionPane.showMessageDialog(null,"Flat ID cannot be 0");
        }else if(bhk==0){
            JOptionPane.showMessageDialog(null,"bhk cannot be 0");
        }
        
        
        
        else{
                  
        try{
            String ins_flat_query="insert into flat values(?,?,?,?,?,?);";
            st=con.prepareStatement(ins_flat_query);
            st.setInt(1,flat_id);
            st.setInt(2,apt_id);
            st.setInt(3,floor);
            st.setInt(4,bhk);
            st.setInt(5, flat_rent_id);
            st.setString(6, active);
            st.execute();
            i_flat_id.setText("");
            i_floor_no.setText("");
            flat_id_get1();
            

            JOptionPane.showMessageDialog(null,"Successfully Inserted!!");
            flat_table_process();
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
        }
    }//GEN-LAST:event_i_add_flat_buttonActionPerformed
 
    private void view_flat_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_view_flat_buttonActionPerformed
        // TODO add your handling code here:
        flat_table_process();
    }//GEN-LAST:event_view_flat_buttonActionPerformed

    private void i_flat_idKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i_flat_idKeyTyped
        // TODO add your handling code here:
        char vchar=evt.getKeyChar();
        if(!(Character.isDigit(vchar))
            ||(vchar==KeyEvent.VK_BACK_SPACE)
            ||(vchar==KeyEvent.VK_DELETE)){
        evt.consume();
        }
    }//GEN-LAST:event_i_flat_idKeyTyped

    private void i_floor_noKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i_floor_noKeyTyped
        // TODO add your handling code here:
        char vchar=evt.getKeyChar();
        if(!(Character.isDigit(vchar))
            ||(vchar==KeyEvent.VK_BACK_SPACE)
            ||(vchar==KeyEvent.VK_DELETE)){
        evt.consume();
        }
    }//GEN-LAST:event_i_floor_noKeyTyped

    private void jPanel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel2MouseClicked
        // TODO add your handling code here:
         /*try{
            int flat_id;
            Statement s;
            String get_apt_id_query="select flat_id from flat;";
            s=con.createStatement();
            r=s.executeQuery(get_apt_id_query);
            boolean b=r.next();
            if(!b){
                JOptionPane.showMessageDialog(null,"no resultset");
            }
            else{
                r.first();
                flat_id=r.getInt("flat_id");
                for(int i=0;i<r.getRow();i++){

                    if(r.next()){
                    int apt_id_i=r.getInt("flat_id");
                    if(flat_id<apt_id_i){
                        flat_id=apt_id_i;
                    }
                    }
                }
               flat_id1=flat_id+1; 

            }
             JOptionPane.showMessageDialog(null,""+flat_id1);
            i_flat_id.setText(String.valueOf(flat_id1));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }*/
    }//GEN-LAST:event_jPanel2MouseClicked

    private void i_flat_apt_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_flat_apt_idActionPerformed
        /*// TODO add your handling code here:
        try{
            int apt_id_flat_id=Integer.parseInt(i_flat_apt_id.getSelectedItem().toString());
            int flat_id;
            PreparedStatement s;
            String get_apt_id_query="select flat_id from flat where apt_id=?;";
            s=con.prepareStatement(get_apt_id_query);
            s.setInt(1, apt_id_flat_id);
            r=s.executeQuery();
            
            
            int count = 0;

            while (r.next()) {
                ++count;
                // Get data from the current row and use it
                }
            
            
            //String[] apt_name_s=new String[count];
            r.beforeFirst();
            boolean b=r.next();
            if(!b){
                JOptionPane.showMessageDialog(null,"no resultset");
                
            }
            else{
                r.first();
                flat_id=r.getInt("flat_id");
                for(int i=0;i<r.getRow();i++){

                    if(r.next()){
                    int apt_id_i=r.getInt("flat_id");
                    if(flat_id<apt_id_i){
                        flat_id=apt_id_i;
                    }
                    }
                }
               flat_id1=flat_id+1; 

            }
            PreparedStatement s1;
            ResultSet r1;
            String check_apt_id_query="select * from apartments where apt_id=?;";
            s1=con.prepareStatement(check_apt_id_query);
            s1.setInt(1, apt_id_flat_id);
            r1=s.executeQuery();
            boolean b1=r1.next();
            if(!b1){
                JOptionPane.showMessageDialog(null,"no resultset");
                
            }
            else{
               int floors=r1.getInt("no_of_flats");
               if(count<=floors){
                   i_flat_id.setText(String.valueOf(flat_id1));
               }else{
                   JOptionPane.showMessageDialog(null,"Number of flats exceeded");
               }
            }
               

            
            
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }*/
    }//GEN-LAST:event_i_flat_apt_idActionPerformed
    
    
    
    private void update_flatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_flatActionPerformed
        // TODO add your handling code here:
        UpdateFlat f=new UpdateFlat();
        f.setVisible(true);
        
    }//GEN-LAST:event_update_flatActionPerformed

    private void delete_flatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_flatActionPerformed
        // TODO add your handling code here:
        DeleteFlat f1=new DeleteFlat();
        f1.setVisible(true);
    }//GEN-LAST:event_delete_flatActionPerformed
public void flat_id_get1(){
        PreparedStatement s;
        ResultSet r2;
        try{
            String active="no";
            int apt_id=Integer.parseInt(i_flat_apt_id1.getSelectedItem().toString());
            String query="select * from flat where apt_id=? and active=?;";
            s=con.prepareStatement(query);
            s.setInt(1, apt_id);
            s.setString(2,active);
            r2=s.executeQuery();
            
           
            int i=0;
            int count = 0;

            while (r2.next()) {
                ++count;
                // Get data from the current row and use it
                }
            String[] flat_id_s=new String[count];
            //String[] apt_name_s=new String[count];
            r2.beforeFirst();
            boolean record=r2.next();
            if(!record){
                JOptionPane.showMessageDialog(null, "no flats are there in apartment id"+apt_id);
            }else{
                do{
                    flat_id_s[i]=String.valueOf(r2.getInt("flat_id"));
                    //apt_name_s[i]=r.getString("apt_name");
                    i++;
                    }while(r2.next());
            }
            DefaultComboBoxModel mod=new DefaultComboBoxModel(flat_id_s);
            //DefaultComboBoxModel mod1=new DefaultComboBoxModel(apt_name_s);
           i_flat_id1.setModel(mod);
            //d_apt_name_tf.setModel(mod1);
            
            
            
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    
    private void i_flat_apt_id1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_flat_apt_id1ActionPerformed
        // TODO add your handling code here:

       

    }//GEN-LAST:event_i_flat_apt_id1ActionPerformed

    private void i_flat_id1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_flat_id1ActionPerformed
        
    }//GEN-LAST:event_i_flat_id1ActionPerformed

    private void i_flat_id1PopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_i_flat_id1PopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        PreparedStatement s;
        ResultSet r2;
        int rent_id=0;
        int bhk=0;
        int cost_rent=0;
        int main_rent=0;
        
        total_rent=cost_rent+main_rent;
        cust_id_set.setEditable(false);
        int apt_id=Integer.parseInt(i_flat_apt_id1.getSelectedItem().toString());
        int flat_id=Integer.parseInt(i_flat_id1.getSelectedItem().toString());
        String a="no";
        try{
            PreparedStatement s1;
            PreparedStatement s2;
            ResultSet r3;
            ResultSet r4;
            String query="select * from flat where apt_id=? and flat_id=?;";
            s1=con.prepareStatement(query);
            s1.setInt(1, apt_id);
            s1.setInt(2, flat_id);
            r3=s1.executeQuery();
            boolean record=r3.next();
            if(!record){
                JOptionPane.showMessageDialog(null, "no bhk");
            }else{
                do{
                    rent_id=r3.getInt("rent_id");
                    bhk=r3.getInt("bhk");
                    
                    }while(r3.next());
            }
            String query1="select * from rent where rent_id=?;";
            s2=con.prepareStatement(query1);
            s2.setInt(1, rent_id);
            r4=s2.executeQuery();
            boolean record1=r4.next();
            if(!record1){
                JOptionPane.showMessageDialog(null, "no rent");
            }else{
                do{
                    int rent=r4.getInt("cost");
                    cust_rent.setText(""+rent);
                    cust_rent.setEditable(false);
                    cost_rent=rent;
                    }while(r4.next());
            }
            
            
            
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
        try{
            PreparedStatement s4;
             ResultSet r5;
             String query2="select * from maintenance where main_id=?;";
             s4=con.prepareStatement(query2);
             s4.setInt(1, bhk);
             r5=s4.executeQuery();
             boolean record1=r5.next();
            if(!record1){
                JOptionPane.showMessageDialog(null, "no main");
            }else{
                do{
                    int main=r5.getInt("cost");
                    cust_main.setText(""+main);
                    cust_main.setEditable(false);
                    main_rent=main;
                    main_id=bhk;
                    }while(r5.next());
            }
            total_rent=cost_rent+main_rent;
            jTextField1.setText(""+total_rent);
            jTextField1.setEditable(false);
            rent_total.setText(""+total_rent);
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
        try{
            
            String query="select active from flat where apt_id=? and flat_id=?;";
            s=con.prepareStatement(query);
            s.setInt(1, apt_id);
            s.setInt(2, flat_id);
            r2=s.executeQuery();
            boolean record=r2.next();
            if(!record){
                JOptionPane.showMessageDialog(null, "no flat");
            }else{
                do{
                    a=r2.getString("active");
                    
                    }while(r2.next());
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "falt "+a);
        }
            if(a.equals("yes")){
                cust_id_set.setEditable(false);
                JOptionPane.showMessageDialog(null, "Already flat is occupied");
                cust_id_set.setText("");
                cust_rent.setText("");
                rent_total.setText("");
                cust_main.setText("");
            }else{
            Statement sa;
            ResultSet ra;
            int cust_id_tb=1;
            
            try{
            
            String querya="select * from customer;";
            sa=con.createStatement();
            ra=sa.executeQuery(querya);
            boolean recorda=ra.next();
            if(!recorda){
                cust_id_set.setText(""+cust_id_tb);
            }else{
                do{
                   int cust_id_tb1=ra.getInt("cust_id");
                   cust_id_tb=cust_id_tb1+1;
                   cust_id_set.setText(""+cust_id_tb);
                    
                    
                    }while(ra.next());
            }
            
            
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
        
        }
    }//GEN-LAST:event_i_flat_id1PopupMenuWillBecomeInvisible

    private void i_flat_apt_id1PopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_i_flat_apt_id1PopupMenuWillBecomeInvisible
        // TODO add your handling code here:
         flat_id_get1();
    }//GEN-LAST:event_i_flat_apt_id1PopupMenuWillBecomeInvisible

    private void i_flat_id1PopupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_i_flat_id1PopupMenuCanceled
        // TODO add your handling code here:
         
    }//GEN-LAST:event_i_flat_id1PopupMenuCanceled

    private void i_flat_apt_idPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_i_flat_apt_idPopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        try{
            int apt_id_flat_id=Integer.parseInt(i_flat_apt_id.getSelectedItem().toString());
            int flat_id=0;
            
            PreparedStatement s;
            String get_apt_id_query="select flat_id from flat where apt_id=?;";
            s=con.prepareStatement(get_apt_id_query);
            s.setInt(1, apt_id_flat_id);
            r=s.executeQuery();
            
            
            int count = 0;

            while (r.next()) {
                ++count;
                // Get data from the current row and use it
                }
            
            
            //String[] apt_name_s=new String[count];
            r.beforeFirst();
            boolean b=r.next();
            if(!b){
                flat_id1=1;
                get_floor_no_empty(count);
                
            }
            else{
                r.first();
                flat_id=r.getInt("flat_id");
                for(int i=0;i<r.getRow();i++){

                    if(r.next()){
                    int apt_id_i=r.getInt("flat_id");
                    if(flat_id<apt_id_i){
                        flat_id=apt_id_i;
                    }
                    }
                }
               flat_id1=flat_id+1; 
               get_floor_no(count);

            }
                          // get_floor_no(count);
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
        
        
        
    }//GEN-LAST:event_i_flat_apt_idPopupMenuWillBecomeInvisible

    private void add_custActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_custActionPerformed
        // TODO add your handling code here:
       
        String active="yes";
        Long icust_phone;
        int apt_id_c=Integer.parseInt(i_flat_apt_id1.getSelectedItem().toString());
        int flat_id_c=Integer.parseInt(i_flat_id1.getSelectedItem().toString());
        int cust_id=Integer.parseInt(cust_id_set.getText());
        String cust_name=cust_name_set.getText();
        icust_phone=Long.parseLong(cust_phone.getText());
        String icust_email=cust_email.getText();
        SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
        String c_date=sdf.format(cust_date.getDate());
        int main_id1=main_id;
        if(cust_name.equals("")){
           JOptionPane.showMessageDialog(null,"enter Customer name");
          }else if(icust_email.equals("")){
              JOptionPane.showMessageDialog(null,"enter Customer Email ID");
          }else if(c_date.equals("")){
              JOptionPane.showMessageDialog(null,"select date of Occupying");
          }else if(!(cust_phone.getText().length()>9)){
           JOptionPane.showMessageDialog(null,"Enter 10 digit number");
       }else{
              try{
                  PreparedStatement s;
                  PreparedStatement s1;
                  PreparedStatement s2;
              boolean e=false;
              String insert_customer="insert into customer values(?,?,?,?,?,?,?,?,?,?);";
              String insert_flat="update flat set active=? where flat_id=? and apt_id=?;";
             // String insert_rent="insert into payment values(?,?,?,?);";
              //s2=con.prepareStatement(insert_rent);
              
              s1=con.prepareStatement(insert_flat);
              
              s=con.prepareStatement(insert_customer);
              s.setInt(1, cust_id);
              s.setInt(2, flat_id_c);
              s.setInt(3, apt_id_c);
              s.setString(4,cust_name);
              s.setLong(5, icust_phone);
              s.setString(6,icust_email);
              s.setString(7,c_date);
              s.setInt(8, main_id1);
              s.setInt(9,Integer.parseInt(cust_rent.getText()));
              s.setInt(10,Integer.parseInt(cust_main.getText()));
              e=s.execute();
              s1.setString(1, active);
              s1.setInt(2, flat_id_c);
              s1.setInt(3, apt_id_c);
              s1.execute();
              //s2.setInt(1, cust_id);
              //s2.setString(2, "null");
              //s2.setString(3, "null");
              //s2.setString(4, "no");
              //s2.execute();
              if(!e){
                  JOptionPane.showMessageDialog(null,"Successfully Inserted!!");
                  cust_id_set.setText("");
                  cust_name_set.setText("");
                  cust_phone.setText("");
                  cust_email.setText("");
                  cust_rent.setText("");
                  cust_main.setText("");
                  cust_table_process();
                  add();
              } 
              else{
                  JOptionPane.showMessageDialog(null,"UnSuccessfully :(");
              }
              
              }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
          }
    }//GEN-LAST:event_add_custActionPerformed

    private void v_custActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_v_custActionPerformed
        // TODO add your handling code here:
        cust_table_process();
    }//GEN-LAST:event_v_custActionPerformed

    private void d_custActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_d_custActionPerformed
        // TODO add your handling code here:
        DeleteCustomer c=new DeleteCustomer();
        c.setVisible(true);
    }//GEN-LAST:event_d_custActionPerformed

    private void u_customerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_u_customerActionPerformed
        // TODO add your handling code here:
        UpdateCustomer u=new UpdateCustomer();
        u.setVisible(true);
    }//GEN-LAST:event_u_customerActionPerformed

    private void s_viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_s_viewActionPerformed
        // TODO add your handling code here:
        s_table_process();
    }//GEN-LAST:event_s_viewActionPerformed
public void s_table_process(){
        s_v_pane.setVisible(true);
        Statement s=null;
        ResultSet rs;
        String apt_select="select * from security;";
        try {
            s=con.createStatement();
            rs=s.executeQuery(apt_select);
            s_v_table.setModel(DbUtils.resultSetToTableModel(rs));
            
        } catch (SQLException e) {
            // TODO Auto-generated catch block
             JOptionPane.showMessageDialog(null, e);
        }   
    }
    
    private void add_security_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_security_buttonActionPerformed
        // TODO add your handling code here:
        int s_id1=Integer.parseInt(s_id.getText());
        String s_name1=s_name.getText();
        String s_shift1=s_shift.getSelectedItem().toString();
        int apt_id_s=Integer.parseInt(s_apt_id.getSelectedItem().toString());
        PreparedStatement p;
        String s_query="insert into security values(?,?,?,?);";
        try{
            p=con.prepareStatement(s_query);
            p.setInt(1, s_id1);
            p.setString(2, s_name1);
            p.setString(3,s_shift1);
            p.setInt(4, apt_id_s);
            p.execute();
            JOptionPane.showMessageDialog(null,"inserted successfully");
            s_table_process();
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
        
        
    }//GEN-LAST:event_add_security_buttonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        DeleteSecurity s=new DeleteSecurity();
        s.setVisible(true);
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void s_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_s_nameActionPerformed
        // TODO add your handling code here:
        try{
            int s_id_got=0;
            int s_set=1;
            PreparedStatement s;
            String get_apt_id_query="select * from security;";
            s=con.prepareStatement(get_apt_id_query);
          
            r=s.executeQuery();
            
            
            int count = 0;

            while (r.next()) {
                ++count;
                // Get data from the current row and use it
                }
            
            
            //String[] apt_name_s=new String[count];
            r.beforeFirst();
            boolean b=r.next();
            if(!b){

               s_id.setText(""+s_set); 
            }
            else{
                r.first();
                s_id_got=r.getInt("security_id");
                for(int i=0;i<count;i++){

                    if(r.next()){
                    int s_id_i=r.getInt("security_id");
                    if(s_id_got<s_id_i){
                        s_id_got=s_id_i;
                    }
                    }
                }
               s_set=s_id_got+1; 
               s_id.setText(""+s_set);

            }
                           
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
        
    }//GEN-LAST:event_s_nameActionPerformed

    private void jPanel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel4MouseClicked
        // TODO add your handling code here:
        try{
            int s_id_got=0;
            int s_set=1;
            PreparedStatement s;
            String get_apt_id_query="select * from security;";
            s=con.prepareStatement(get_apt_id_query);
          
            r=s.executeQuery();
            
            
            int count = 0;

            while (r.next()) {
                ++count;
                // Get data from the current row and use it
                }
            
            
            //String[] apt_name_s=new String[count];
            r.beforeFirst();
            boolean b=r.next();
            if(!b){

                
            }
            else{
                r.first();
                s_id_got=r.getInt("security_id");
                for(int i=0;i<count;i++){

                    if(r.next()){
                    int s_id_i=r.getInt("security_id");
                    if(s_id_got<s_id_i){
                        s_id_got=s_id_i;
                    }
                    }
                }
               s_set=s_id_got+1; 
               s_id.setText(""+s_set);

            }
                           
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
        
    }//GEN-LAST:event_jPanel4MouseClicked

    private void s_nameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_s_nameMouseClicked
        // TODO add your handling code here:
        try{
            int s_id_got=0;
            int s_set=1;
            PreparedStatement s;
            String get_apt_id_query="select * from security;";
            s=con.prepareStatement(get_apt_id_query);
          
            r=s.executeQuery();
            
            
            int count = 0;

            while (r.next()) {
                ++count;
                // Get data from the current row and use it
                }
            
            
            //String[] apt_name_s=new String[count];
            r.beforeFirst();
            boolean b=r.next();
            if(!b){
            s_id.setText(""+s_set);
                
            }
            else{
                r.first();
                s_id_got=r.getInt("security_id");
                for(int i=0;i<count;i++){

                    if(r.next()){
                    int s_id_i=r.getInt("security_id");
                    if(s_id_got<s_id_i){
                        s_id_got=s_id_i;
                    }
                    }
                }
               s_set=s_id_got+1; 
               s_id.setText(""+s_set);

            }
                           
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
        
    }//GEN-LAST:event_s_nameMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
       
    
        int cust_id_r=Integer.parseInt(jComboBox1.getSelectedItem().toString());
        String pay_type_r=jComboBox2.getSelectedItem().toString();
         SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
         SimpleDateFormat pdf=new SimpleDateFormat("MM-yyyy");
        String c_date1=sdf.format(jDateChooser1.getDate());
        String pm_date=pdf.format(jDateChooser2.getDate());
        String payed="yes";
        PreparedStatement s1;
        ResultSet r1;
        try{
            String query="insert into payment values(?,?,?,?,?);";
            s1=con.prepareStatement(query);
            s1.setInt(1, cust_id_r);
            
            s1.setString(2, pay_type_r);
            s1.setString(3, c_date1);
            s1.setString(4, payed);
            s1.setString(5, pm_date);
            s1.execute();
            JOptionPane.showMessageDialog(null,"Paid");
            payed_table_process();
        }
         catch(SQLException e){
            JOptionPane.showMessageDialog(null,"already paid");
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void not_paid_bActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_not_paid_bActionPerformed
        // TODO add your handling code here:
       // not_payed_table_process();
       pay_view pp=new pay_view();
       pp.setVisible(true);
        
    }//GEN-LAST:event_not_paid_bActionPerformed

    private void jComboBox2PopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_jComboBox2PopupMenuWillBecomeInvisible
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2PopupMenuWillBecomeInvisible

    private void jComboBox1PopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_jComboBox1PopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        get_pay_rent();
        rent_total.setText(""+total_rent);
    }//GEN-LAST:event_jComboBox1PopupMenuWillBecomeInvisible

    private void jPanel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel9MouseClicked
        // TODO add your handling code here:
        add();
    }//GEN-LAST:event_jPanel9MouseClicked

    private void paid_bActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paid_bActionPerformed
        // TODO add your handling code here:
        payed_table_process();
    }//GEN-LAST:event_paid_bActionPerformed

    private void cust_phoneKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cust_phoneKeyTyped
        // TODO add your handling code here:
       
        char vchar=evt.getKeyChar();
       
       
        if(!(Character.isDigit(vchar))
            ||(vchar==KeyEvent.VK_BACK_SPACE)
            ||(vchar==KeyEvent.VK_DELETE)){
           
            
        evt.consume();
            
        }
        
        if(!(cust_phone.getText().length()<10)){
           evt.consume();
       }
    }//GEN-LAST:event_cust_phoneKeyTyped
    
    
    private void update_rent_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_rent_buttonActionPerformed
        // TODO add your handling code here:
        rent_main_win r=new rent_main_win();
        r.setVisible(true);
    }//GEN-LAST:event_update_rent_buttonActionPerformed

    private void jComboBox3PopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_jComboBox3PopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        flat_id_get12();
        jPanel11.setVisible(true);
    }//GEN-LAST:event_jComboBox3PopupMenuWillBecomeInvisible

    private void i_flat_apt_idPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_i_flat_apt_idPopupMenuWillBecomeVisible
        // TODO add your handling code here:
       i_flat_id.setText(null);
       
 
    }//GEN-LAST:event_i_flat_apt_idPopupMenuWillBecomeVisible

    private void i_flat_apt_idPopupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_i_flat_apt_idPopupMenuCanceled
        // TODO add your handling code here:
        
    }//GEN-LAST:event_i_flat_apt_idPopupMenuCanceled

    private void cust_phoneKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cust_phoneKeyPressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_cust_phoneKeyPressed

    private void cust_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cust_emailActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_cust_emailActionPerformed

    private void cust_emailKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cust_emailKeyTyped
        // TODO add your handling code here:
       
    }//GEN-LAST:event_cust_emailKeyTyped
   
    public void flat_id_get12(){
        PreparedStatement s;
        ResultSet r2;
        try{
            String active="no";
            int apt_id=Integer.parseInt(jComboBox3.getSelectedItem().toString());
            String query="select flat_id from flat where apt_id=? and active=?;";
            s=con.prepareStatement(query);
            s.setInt(1, apt_id);
            s.setString(2,active);
            r2=s.executeQuery();
             jTable1.setModel(DbUtils.resultSetToTableModel(r2));
           r2.beforeFirst();
            int i=0;
            int count = 0;

            while (r2.next()) {
                ++count;
                // Get data from the current row and use it
                }
            jTextField2.setText(""+count);
            r2.beforeFirst();
            
            
            //d_apt_name_tf.setModel(mod1);
            
            
            
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    
    public void get_pay_rent(){
        PreparedStatement s;
        ResultSet r2;
        int rent_id=0;
        int bhk=0;
        int cost_rent=0;
        int main_rent=0;
        int cust_id1=Integer.parseInt(jComboBox1.getSelectedItem().toString());
        
        cust_id_set.setEditable(false);
        int apt_id=0;
        int flat_id=0;
        String a="no";
         try{
            PreparedStatement s4;
             ResultSet r5;
             String query2="select * from customer where cust_id=?;";
             s4=con.prepareStatement(query2);
             s4.setInt(1, cust_id1);
             r5=s4.executeQuery();
             boolean record1=r5.next();
            if(!record1){
                JOptionPane.showMessageDialog(null, "no customer");
            }else{
                do{
                    apt_id=r5.getInt("apt_id");
                    flat_id=r5.getInt("flat_id");
            }while(r5.next());
            } 
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
        try{
            PreparedStatement s1;
            PreparedStatement s2;
            ResultSet r3;
            ResultSet r4;
            String query="select * from flat where apt_id=? and flat_id=?;";
            s1=con.prepareStatement(query);
            s1.setInt(1, apt_id);
            s1.setInt(2, flat_id);
            r3=s1.executeQuery();
            boolean record=r3.next();
            if(!record){
                JOptionPane.showMessageDialog(null, "no bhk");
            }else{
                do{
                    rent_id=r3.getInt("rent_id");
                    bhk=r3.getInt("bhk");
                    
                    }while(r3.next());
            }
            String query1="select * from rent where rent_id=?;";
            s2=con.prepareStatement(query1);
            s2.setInt(1, rent_id);
            r4=s2.executeQuery();
            boolean record1=r4.next();
            if(!record1){
                JOptionPane.showMessageDialog(null, "no rent");
            }else{
                do{
                    int rent=r4.getInt("cost");
                    cust_rent.setText(""+rent);
                    cust_rent.setEditable(false);
                    cost_rent=rent;
                    }while(r4.next());
            }
            
            
            
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
        try{
            PreparedStatement s4;
             ResultSet r5;
             String query2="select * from maintenance where main_id=?;";
             s4=con.prepareStatement(query2);
             s4.setInt(1, bhk);
             r5=s4.executeQuery();
             boolean record1=r5.next();
            if(!record1){
                JOptionPane.showMessageDialog(null, "no main");
            }else{
                do{
                    int main=r5.getInt("cost");
                    cust_main.setText(""+main);
                    cust_main.setEditable(false);
                    main_rent=main;
                    main_id=bhk;
                    }while(r5.next());
            }
            total_rent=cost_rent+main_rent;
            jTextField1.setText(""+total_rent);
            jTextField1.setEditable(false);
            rent_total.setText(""+total_rent);
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
       
        
        
       
    }
    
    public void payed_table_process(){
        cust_table_panel1.setVisible(true);
        Statement s=null;
        ResultSet rs;
        String status="yes";
        String apt_select="select * from payment where status='"+status+"'";
        try {
            s=con.createStatement();
            rs=s.executeQuery(apt_select);
            cust_details_table1.setModel(DbUtils.resultSetToTableModel(rs));
            
        } catch (SQLException e) {
            // TODO Auto-generated catch block
             JOptionPane.showMessageDialog(null, e);
        }   
    }
     public void not_payed_table_process(){
        cust_table_panel1.setVisible(true);
        Statement s=null;
        ResultSet rs;
        String status="no";
        String apt_select1="select * from payment where status='"+status+"'";
        try {
            s=con.createStatement();
            rs=s.executeQuery(apt_select1);
            cust_details_table1.setModel(DbUtils.resultSetToTableModel(rs));
            
        } catch (SQLException e) {
            // TODO Auto-generated catch block
             JOptionPane.showMessageDialog(null, e);
        }   
    }
    public void cust_table_process(){
        cust_table_panel.setVisible(true);
        Statement s=null;
        ResultSet rs;
        String apt_select="select cust_id,flat_id,apt_id,cust_name,phno,email,date_start,main_cost,rent_cost from customer;";
        try {
            s=con.createStatement();
            rs=s.executeQuery(apt_select);
            cust_details_table.setModel(DbUtils.resultSetToTableModel(rs));
            
        } catch (SQLException e) {
            // TODO Auto-generated catch block
             JOptionPane.showMessageDialog(null, e);
        }   
    }
    
    
    public void get_floor_no(int count){
        PreparedStatement s1;
            ResultSet r1;
            int apt_id_flat_id=Integer.parseInt(i_flat_apt_id.getSelectedItem().toString());
            try{
            String check_apt_id_query="select * from apartments where apt_id=?;";
            s1=con.prepareStatement(check_apt_id_query);
            s1.setInt(1, apt_id_flat_id);
            r1=s1.executeQuery();
            boolean b1=r1.next();
            if(!b1){
                JOptionPane.showMessageDialog(null,"no resultset");
                
            }
            else{
               int floors=r1.getInt(6);
               if(count<=floors){
                   i_flat_id.setText(String.valueOf(flat_id1));
                   i_flat_id.setEditable(false);
               }else{
                   JOptionPane.showMessageDialog(null,"Number of flats exceeded");
               }
            }
               

            }
            
        
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
            
    }
    public void get_floor_no_empty(int count){
        PreparedStatement s1;
            ResultSet r1;
            int apt_id_flat_id=Integer.parseInt(i_flat_apt_id.getSelectedItem().toString());
            try{
            String check_apt_id_query="select * from apartments where apt_id=?;";
            s1=con.prepareStatement(check_apt_id_query);
            s1.setInt(1, apt_id_flat_id);
            r1=s1.executeQuery();
            boolean b1=r1.next();
            if(!b1){
                JOptionPane.showMessageDialog(null,"no resultset");
                
            }
            else{
               int floors=r1.getInt(6);
               if(count<=floors){
                   i_flat_id.setText(String.valueOf(flat_id1));
                   i_flat_id.setEditable(false);
               }else{
                   JOptionPane.showMessageDialog(null,"Number of flats exceeded");
               }
            }
               

            }
            
        
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
            
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(main_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(main_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(main_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(main_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new main_page().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane Scroll2;
    private javax.swing.JButton add_apt_details_button;
    private javax.swing.JButton add_cust;
    private javax.swing.JButton add_security_button;
    private javax.swing.JScrollPane apt_Scroll;
    private javax.swing.JTextField apt_address_tf;
    private javax.swing.JTextField apt_city_tf;
    private javax.swing.JButton apt_delete_win_button;
    private javax.swing.JTable apt_details_table;
    private javax.swing.JTextField apt_id_tf;
    private javax.swing.JTextField apt_name_tf;
    private javax.swing.JTextField apt_no_flats_tf;
    private javax.swing.JTextField apt_state_tf;
    private javax.swing.JPanel apt_table_panel;
    private javax.swing.JButton apt_update_win_button;
    private javax.swing.JButton apt_view_button;
    private com.toedter.calendar.JDateChooser cust_date;
    private javax.swing.JTable cust_details_table;
    private javax.swing.JTable cust_details_table1;
    private javax.swing.JTextField cust_email;
    private javax.swing.JTextField cust_id_set;
    private javax.swing.JTextField cust_main;
    private javax.swing.JTextField cust_name_set;
    private javax.swing.JTextField cust_phone;
    private javax.swing.JTextField cust_rent;
    private javax.swing.JPanel cust_table_panel;
    private javax.swing.JPanel cust_table_panel1;
    private javax.swing.JScrollPane customer_Scroll1;
    private javax.swing.JScrollPane customer_Scroll2;
    private javax.swing.JButton d_cust;
    private javax.swing.JButton delete_flat;
    private javax.swing.JScrollPane flat_Scroll1;
    private javax.swing.JTable flat_details_table1;
    private javax.swing.JPanel flat_table_panel1;
    private javax.swing.JButton i_add_flat_button;
    private javax.swing.JComboBox<String> i_bhk;
    private javax.swing.JComboBox<String> i_flat_apt_id;
    private javax.swing.JComboBox<String> i_flat_apt_id1;
    private javax.swing.JTextField i_flat_id;
    private javax.swing.JComboBox<String> i_flat_id1;
    private javax.swing.JTextField i_floor_no;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JButton not_paid_b;
    private javax.swing.JButton paid_b;
    private javax.swing.JTextField rent_total;
    private javax.swing.JComboBox<String> s_apt_id;
    private javax.swing.JTextField s_id;
    private javax.swing.JTextField s_name;
    private javax.swing.JComboBox<String> s_shift;
    private javax.swing.JPanel s_v_pane;
    private javax.swing.JTable s_v_table;
    private javax.swing.JButton s_view;
    private javax.swing.JButton u_customer;
    private javax.swing.JButton update_flat;
    private javax.swing.JButton update_rent_button;
    private javax.swing.JButton v_cust;
    private javax.swing.JButton view_flat_button;
    // End of variables declaration//GEN-END:variables
}
