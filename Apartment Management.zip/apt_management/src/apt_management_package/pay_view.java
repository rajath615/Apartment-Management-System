/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apt_management_package;

import java.sql.*;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author RAJATH
 */
public class pay_view extends javax.swing.JFrame {
Connection ad;

    /**
     * Creates new form apt_view
     */
    public pay_view() {
        initComponents();
        
        
        connect();
        Trigger();
        pay_table_panel_d.setOpaque(false);
    }
   public void Trigger(){
    DateFormat dateFormat = new SimpleDateFormat("MM-yyyy");
    Calendar cal = Calendar.getInstance();
     String d=dateFormat.format(cal.getTime());
    
    PreparedStatement p=null;
    PreparedStatement p1=null;
    ResultSet s;
    ResultSet s1;
    int[] all_c_id;
    int[] pay_c_id;
    int[] not_pay_c_id;
    int count = 0;
    int count1 = 0;
    int y=0;
    String status="yes";
    String query_all_cust="select * from customer;";
    String query_payed_cust="select * from payment where status=? and paying_for_month=?;";
    try{
      
        p=ad.prepareStatement(query_all_cust);
        s=p.executeQuery();
        int i=0;
            

            while (s.next()) {
                ++count;
                // Get data from the current row and use it
                }
            all_c_id=new int[count];
            s.beforeFirst();
            boolean record=s.next();
            if(!record){
                JOptionPane.showMessageDialog(null, "no records");
            }else{
                do{
                    all_c_id[i]=s.getInt("cust_id");
                    
                    i++;
                    }while(s.next());
            }
           
        p1=ad.prepareStatement(query_payed_cust);
        p1.setString(1,status);
        p1.setString(2,d);
        s1=p1.executeQuery();
        int i1=0;
            

            while (s1.next()) {
                ++count1;
                // Get data from the current row and use it
                }
            pay_c_id=new int[count1];
            s1.beforeFirst();
            boolean record1=s1.next();
            if(!record1){
                JOptionPane.showMessageDialog(null, "no records");
            }else{
                do{
                    pay_c_id[i1]=s1.getInt("cust_id");
                   // JOptionPane.showMessageDialog(null, ""+pay_c_id[i1]);
                    i1++;
                    }while(s1.next());
            }
           
            
         not_pay_c_id=new int[50]; 
         Arrays.sort(all_c_id);
         Arrays.sort(pay_c_id);
         
         
       /*for (int k = 0; k < all_c_id.length; k++) {
        for (int j = i + 1; j < all_c_id.length; j++) {
            int tmp = 0;
            if (all_c_id[k] > all_c_id[j]) {
                tmp = all_c_id[k];
                all_c_id[k] = all_c_id[j];
                all_c_id[j] = tmp;
            }
        }
    }
    
        for (int k1 = 0; k1 < pay_c_id.length; k1++) {
        for (int j1 = i + 1; j1 < pay_c_id.length; j1++) {
            int tmp = 0;
            if (pay_c_id[k1] > pay_c_id[j1]) {
                tmp = pay_c_id[k1];
                pay_c_id[k1] = pay_c_id[j1];
                pay_c_id[j1] = tmp;
            }
        }
    }*/
        
        for(int i5=0;i5<all_c_id.length; i5++){
            /*boolean got=false;
            for(int j5=0;j5<pay_c_id.length; j5++){
                if(all_c_id[i5]==pay_c_id[j5]){
                 got=true;   
                JOptionPane.showMessageDialog(null, ""+all_c_id[i5]);
                }else{
                    got=false;
                }
                
                }
            if(got==false){
                   not_pay_c_id[y]=all_c_id[i5];
                   JOptionPane.showMessageDialog(null, "not"+not_pay_c_id[y]);
                   y++;
            }
            */
            int search=all_c_id[i5];
            int first=0;
            int last=pay_c_id.length-1;
            int middle=(first+last)/2;
            while(first<=last){
                if(pay_c_id[middle]==search){
                    //JOptionPane.showMessageDialog(null, "got"+all_c_id[i5]);
                    break;
                }else if(pay_c_id[middle]<search){
                    first=middle+1;
                }
                else
                    last=middle-1;
                middle=(first+last)/2;
            }
            if(first>last){
                not_pay_c_id[y]=all_c_id[i5];
                y++;
            }
        }
       //JOptionPane.showMessageDialog(null, "got");
        boolean record10=false;
          
         int count_id=not_pay_c_id.length;
         String trigg="select * from customer where cust_id=?";
        
         int i10=0;
         
        while(i10<count_id){
           try{ 
               PreparedStatement pp=ad.prepareStatement(trigg);
        // JOptionPane.showMessageDialog(null, "triggasdsafafs");
           pp.setInt(1, not_pay_c_id[i10]);
           ResultSet rr=pp.executeQuery();
           record10=rr.next();
           //JOptionPane.showMessageDialog(null, "got");
           if(!record10){
             //JOptionPane.showMessageDialog(null, "all payed");  
           }else{
               Object rowData[]=new Object[5];
               rowData[0]=String.valueOf(rr.getInt("cust_id"));
               rowData[1]=String.valueOf(rr.getInt("apt_id"));
               rowData[2]=String.valueOf(rr.getInt("flat_id"));
               rowData[3]=rr.getString("cust_name");
               rowData[4]=rr.getString("date_start");
               DefaultTableModel mod=(DefaultTableModel)pay_details_table_d.getModel();
               mod.addRow(rowData);
               
              
           }}catch(SQLException e){
        JOptionPane.showMessageDialog(null, e);
        
    }
          i10++;  
        }
         
    }catch(SQLException e){
        JOptionPane.showMessageDialog(null, e);
    }
    
     //JOptionPane.showMessageDialog(null, d);
    }
    public void connect()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            ad=DriverManager.getConnection("jdbc:mysql://localhost/apt_db","root","root123");
            
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    /*public void apt_table_process(){
        pay_table_panel_d.setVisible(true);
        Statement s=null;
        ResultSet rs;
        String apt_select="select * from apartments";
        try {
            s=ad.createStatement();
            rs=s.executeQuery(apt_select);
            pay_details_table_d.setModel(DbUtils.resultSetToTableModel(rs));
            ad.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
             JOptionPane.showMessageDialog(null, e);
        }     
        
          
    }*/
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pay_table_panel_d = new javax.swing.JPanel();
        pay_Scroll = new javax.swing.JScrollPane();
        pay_details_table_d = new javax.swing.JTable();
        pay_exit = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pay_Scroll.setBorder(null);
        pay_Scroll.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N

        pay_details_table_d.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        pay_details_table_d.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Customer_ID", "Apartment ID", "Flat_id", "Customer_name", "Occupied Date"
            }
        ));
        pay_details_table_d.setRowHeight(25);
        pay_Scroll.setViewportView(pay_details_table_d);

        pay_exit.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        pay_exit.setText("Exit");
        pay_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pay_exitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pay_table_panel_dLayout = new javax.swing.GroupLayout(pay_table_panel_d);
        pay_table_panel_d.setLayout(pay_table_panel_dLayout);
        pay_table_panel_dLayout.setHorizontalGroup(
            pay_table_panel_dLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pay_Scroll, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1007, Short.MAX_VALUE)
            .addGroup(pay_table_panel_dLayout.createSequentialGroup()
                .addGap(401, 401, 401)
                .addComponent(pay_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pay_table_panel_dLayout.setVerticalGroup(
            pay_table_panel_dLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pay_table_panel_dLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pay_Scroll, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pay_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        getContentPane().add(pay_table_panel_d, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 13, -1, -1));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1030, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pay_exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pay_exitActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_pay_exitActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pay_view.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pay_view.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pay_view.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pay_view.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new pay_view().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane pay_Scroll;
    private javax.swing.JTable pay_details_table_d;
    private javax.swing.JButton pay_exit;
    private javax.swing.JPanel pay_table_panel_d;
    // End of variables declaration//GEN-END:variables
}
