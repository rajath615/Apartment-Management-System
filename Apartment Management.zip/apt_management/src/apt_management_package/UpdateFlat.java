/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apt_management_package;

import java.awt.event.KeyEvent;
import java.sql.*;
import java.sql.PreparedStatement;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author RAJATH
 */
public class UpdateFlat extends javax.swing.JFrame {
    Connection uf;
    PreparedStatement st=null;
    int flat_rent_id;
    int flat_id1;
    /**
     * Creates new form f_u_win
     */
    public UpdateFlat() {
        initComponents();
        this.setSize(1920,1030);
        connect();
         apt_id_get();
         bhk_get();
         flat_table_panel1.setVisible(false);
         flat_table_panel1.setOpaque(false);
         flat_Scroll1.setOpaque(false);
         
    }
     public void get_rent_id(){
        int bhk=Integer.parseInt(i_bhk.getSelectedItem().toString());
        PreparedStatement s=null;
        ResultSet rs;
        String apt_select="select rent_id from rent where bhk=?";
        try {
            s=uf.prepareStatement(apt_select);
            s.setInt(1, bhk);
            rs=s.executeQuery();
            boolean b=rs.next();
            if(!b){
                JOptionPane.showMessageDialog(null,"no resultset");
            }
            else{
                flat_rent_id=rs.getInt("rent_id");

            }
            
        } catch (SQLException e) {
            // TODO Auto-generated catch block
             JOptionPane.showMessageDialog(null, e);
        }     
        
    }
    public void bhk_get(){
        Statement s;
        ResultSet r;
        try{
            String query="select * from rent;";
            s=uf.createStatement();
            r=s.executeQuery(query);
            
           
            int i=0;
            int count = 0;

            while (r.next()) {
                ++count;
                // Get data from the current row and use it
                }
            String[] bhk_s=new String[count];
            //String[] apt_name_s=new String[count];
            r.beforeFirst();
            boolean record=r.next();
            if(!record){
                JOptionPane.showMessageDialog(null, "no records");
            }else{
                do{
                    bhk_s[i]=String.valueOf(r.getInt("bhk"));
                    //apt_name_s[i]=r.getString("apt_name");
                    i++;
                    }while(r.next());
            }
            DefaultComboBoxModel mod_bhk=new DefaultComboBoxModel(bhk_s);
            //DefaultComboBoxModel mod1=new DefaultComboBoxModel(apt_name_s);
           i_bhk.setModel(mod_bhk);
            //d_apt_name_tf.setModel(mod1);
            
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    public void apt_id_get(){
        Statement s;
        ResultSet r;
        try{
            String query="select * from apartments;";
            s=uf.createStatement();
            r=s.executeQuery(query);
            
           
            int i=0;
            int count = 0;

            while (r.next()) {
                ++count;
                // Get data from the current row and use it
                }
            String[] apt_id_s=new String[count];
            //String[] apt_name_s=new String[count];
            r.beforeFirst();
            boolean record=r.next();
            if(!record){
                JOptionPane.showMessageDialog(null, "no records");
            }else{
                do{
                    apt_id_s[i]=String.valueOf(r.getInt("apt_id"));
                    //apt_name_s[i]=r.getString("apt_name");
                    i++;
                    }while(r.next());
            }
            DefaultComboBoxModel mod=new DefaultComboBoxModel(apt_id_s);
            //DefaultComboBoxModel mod1=new DefaultComboBoxModel(apt_name_s);
           i_flat_apt_id.setModel(mod);
            //d_apt_name_tf.setModel(mod1);
            
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    public void flat_id_get(){
        PreparedStatement s;
        ResultSet r;
        try{
            int apt_id=Integer.parseInt(i_flat_apt_id.getSelectedItem().toString());
            String query="select * from flat where apt_id=?;";
            s=uf.prepareStatement(query);
            s.setInt(1, apt_id);
            r=s.executeQuery();
            
           
            int i=0;
            int count = 0;

            while (r.next()) {
                ++count;
                // Get data from the current row and use it
                }
            String[] flat_id_s=new String[count];
            //String[] apt_name_s=new String[count];
            r.beforeFirst();
            boolean record=r.next();
            if(!record){
                JOptionPane.showMessageDialog(null, "no records");
            }else{
                do{
                    flat_id_s[i]=String.valueOf(r.getInt("flat_id"));
                    //apt_name_s[i]=r.getString("apt_name");
                    i++;
                    }while(r.next());
            }
            DefaultComboBoxModel mod=new DefaultComboBoxModel(flat_id_s);
            //DefaultComboBoxModel mod1=new DefaultComboBoxModel(apt_name_s);
           i_flat_id.setModel(mod);
            //d_apt_name_tf.setModel(mod1);
            
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    
    public void connect()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            uf=DriverManager.getConnection("jdbc:mysql://localhost/apt_db","root","root123");
            
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel9 = new javax.swing.JLabel();
        i_flat_apt_id = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        i_floor_no = new javax.swing.JTextField();
        i_bhk = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        update_button = new javax.swing.JButton();
        i_flat_id = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        flat_table_panel1 = new javax.swing.JPanel();
        flat_Scroll1 = new javax.swing.JScrollPane();
        flat_details_table1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel9.setText("Apartment ID");
        jLabel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 168, 150, 30));

        i_flat_apt_id.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        i_flat_apt_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_flat_apt_idActionPerformed(evt);
            }
        });
        getContentPane().add(i_flat_apt_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(375, 168, 200, 30));

        jLabel8.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel8.setText("Flat ID");
        jLabel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 220, 150, 30));

        jLabel10.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel10.setText("Floor");
        jLabel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 270, 150, 30));

        i_floor_no.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        i_floor_no.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_floor_noActionPerformed(evt);
            }
        });
        i_floor_no.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                i_floor_noKeyTyped(evt);
            }
        });
        getContentPane().add(i_floor_no, new org.netbeans.lib.awtextra.AbsoluteConstraints(375, 270, 200, 30));

        i_bhk.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        getContentPane().add(i_bhk, new org.netbeans.lib.awtextra.AbsoluteConstraints(375, 320, 200, 30));

        jLabel11.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jLabel11.setText("BHK");
        jLabel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 320, 150, 30));

        update_button.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        update_button.setText("Update Flat");
        update_button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        update_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_buttonActionPerformed(evt);
            }
        });
        getContentPane().add(update_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(189, 403, 150, 30));

        i_flat_id.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        getContentPane().add(i_flat_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(375, 216, 200, 30));

        jButton1.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N
        jButton1.setText("Back");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(371, 403, 150, 30));

        jLabel1.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 24)); // NOI18N
        jLabel1.setText("Update Flat");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(267, 47, 169, 46));

        flat_Scroll1.setBorder(null);
        flat_Scroll1.setFont(new java.awt.Font("Adobe Caslon Pro Bold", 1, 18)); // NOI18N

        flat_details_table1.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        flat_details_table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        flat_details_table1.setRowHeight(25);
        flat_Scroll1.setViewportView(flat_details_table1);

        javax.swing.GroupLayout flat_table_panel1Layout = new javax.swing.GroupLayout(flat_table_panel1);
        flat_table_panel1.setLayout(flat_table_panel1Layout);
        flat_table_panel1Layout.setHorizontalGroup(
            flat_table_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(flat_Scroll1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 780, Short.MAX_VALUE)
        );
        flat_table_panel1Layout.setVerticalGroup(
            flat_table_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, flat_table_panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(flat_Scroll1, javax.swing.GroupLayout.DEFAULT_SIZE, 601, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(flat_table_panel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(669, 62, -1, 627));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/apt1.jpg"))); // NOI18N
        jLabel2.setMaximumSize(new java.awt.Dimension(1920, 1030));
        jLabel2.setMinimumSize(new java.awt.Dimension(1920, 1030));
        jLabel2.setPreferredSize(new java.awt.Dimension(1920, 1030));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1920, 1030));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void i_flat_apt_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_flat_apt_idActionPerformed
        // TODO add your handling code here:
        
            flat_id_get();
            
       
    }//GEN-LAST:event_i_flat_apt_idActionPerformed

    private void i_floor_noKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i_floor_noKeyTyped
        // TODO add your handling code here:
        char vchar=evt.getKeyChar();
        if(!(Character.isDigit(vchar))
            ||(vchar==KeyEvent.VK_BACK_SPACE)
            ||(vchar==KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_i_floor_noKeyTyped

    private void update_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_buttonActionPerformed
        // TODO add your handling code here:
        try{
            boolean b=false;
            ResultSet r;
            get_rent_id();
            int flat_id_got=Integer.parseInt(i_flat_id.getSelectedItem().toString());
            int apt_id=Integer.parseInt(i_flat_apt_id.getSelectedItem().toString());
            int floor=Integer.parseInt(i_floor_no.getText());
            int bhk=Integer.parseInt(i_bhk.getSelectedItem().toString());
            String active="no";
           
            PreparedStatement s;
            String get_apt_id_query="update flat set bhk=?,floor=?,rent_id=? where apt_id=? and flat_id=?;";
            s=uf.prepareStatement(get_apt_id_query);
            s.setInt(1, bhk);
            s.setInt(2, floor);
            s.setInt(3, flat_rent_id);
            s.setInt(4, apt_id);
            s.setInt(5, flat_id_got);
            b=s.execute();
            i_floor_no.setText("");
            if(!b){
                    JOptionPane.showMessageDialog(null,"Successfully Updated!!");
                    flat_table_process();
                    
                }else{
                    JOptionPane.showMessageDialog(null,"wrong");
                }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }//GEN-LAST:event_update_buttonActionPerformed
public void flat_table_process(){
        flat_table_panel1.setVisible(true);
        Statement s=null;
        ResultSet rs;
        String apt_select="select flat_id,apt_id,floor,bhk,active from flat";
        try {
            s=uf.createStatement();
            rs=s.executeQuery(apt_select);
            flat_details_table1.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException e) {
            // TODO Auto-generated catch block
             JOptionPane.showMessageDialog(null, e);
        }     
        
          
    }
    private void i_floor_noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_floor_noActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_i_floor_noActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdateFlat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdateFlat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdateFlat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdateFlat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdateFlat().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane flat_Scroll1;
    private javax.swing.JTable flat_details_table1;
    private javax.swing.JPanel flat_table_panel1;
    private javax.swing.JComboBox<String> i_bhk;
    private javax.swing.JComboBox<String> i_flat_apt_id;
    private javax.swing.JComboBox<String> i_flat_id;
    private javax.swing.JTextField i_floor_no;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JButton update_button;
    // End of variables declaration//GEN-END:variables
}
